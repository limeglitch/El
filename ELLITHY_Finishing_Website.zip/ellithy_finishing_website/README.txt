ELLITHY Finishing Website
=========================
- افتح index.html لتشغيل الموقع.
- اترك مجلد images بجوار index.html كما هو.
- لتفعيل واتساب: افتح index.html وابحث عن WHATSAPP_NUMBER وضع الرقم بصيغة دولية بدون + أو مسافات.
  مثال رقم مصري: 2010XXXXXXX
- أرسل روابط TikTok وInstagram ورقم الواتساب وسأضيفها لك في النسخة النهائية.
